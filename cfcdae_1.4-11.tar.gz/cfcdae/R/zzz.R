.onLoad <- function(libname,pkgname)
{
	options(contrasts=c("contr.sum","contr.poly"))
}
